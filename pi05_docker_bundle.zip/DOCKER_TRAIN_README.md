# pi0.5 60-D full-training Docker bundle

Put Dockerfile.train and Dockerfile.train.dockerignore at YOUR tested OpenPI
repository root. Put the two scripts under its scripts/ directory. Build from
that root, using your existing pyproject.toml, uv.lock and modified source code:

```bash
docker build --platform linux/amd64 -f Dockerfile.train -t openpi-pi05-60d:train .
docker save -o openpi-pi05-60d.tar openpi-pi05-60d:train
```

Build requires access to container registries, PyPI and GitHub for dependencies.
It does NOT download pretrained model weights. H100 runtime uses --network none.
Image excludes local .venv, assets, checkpoints and caches. Transfer the image,
dataset parent, exact norm_stats.json folder, REAL projection checkpoint and
OpenPI tokenizer cache separately to the H100 machine. Use an x86_64 Linux H100
host with Docker Engine and NVIDIA Container Toolkit and a CUDA12-compatible
driver. The locked project must include GPU-enabled JAX (jax[cuda12]).

On H100:

```bash
docker load -i /path/to/openpi-pi05-60d.tar
docker run --rm --gpus device=0 --network none openpi-pi05-60d:train nvidia-smi
docker run --rm --gpus device=0 --network none openpi-pi05-60d:train python -c "import jax; print(jax.devices())"
```

Configure HOST paths:

```bash
export DATASET_DIR=/path/to/260921_all_25hz_300epi
export INIT_CHECKPOINT=/path/to/real_projection_checkpoint/10000
export NORM_STATS_FILE=/path/to/assets/pi05_projection_60d_multi/260921_all_25hz_300epi/norm_stats.json
export CACHE_DIR=/path/to/.openpi_cache
export OUTPUT_DIR=/path/to/full_training_checkpoints
export GPU_INDEX=0
```

Use the actual path of your REAL 60-D projection checkpoint. Do NOT use the
dummy/mu smoke-test checkpoint: its tensors cannot initialize the full model.
Norm stats must be from training; they are not recomputed. Cache must contain
big_vision/paligemma_tokenizer.model. None of these are embedded in the image.

```bash
# Optional config/GPU/path check, no weights loaded:
CONTAINER_NAME=pi05-preflight bash scripts/run_h100.sh preflight
docker logs -f pi05-preflight

# Real pi0.5, real initial checkpoint, full backward/update, 3 steps, batch 1:
CONTAINER_NAME=pi05-h100-smoke bash scripts/run_h100.sh smoke
docker logs -f pi05-h100-smoke
docker inspect -f '{{.State.ExitCode}}' pi05-h100-smoke

# Normal full training, 50,000 updates, initially batch 4:
export EXP_NAME=full_60d_v1
CONTAINER_NAME=pi05-full bash scripts/run_h100.sh full
docker logs -f pi05-full

# Later, resume this same experiment, including optimizer state:
CONTAINER_NAME=pi05-full-resume bash scripts/run_h100.sh resume
```

Choose a new container name for every launch. Completed containers are retained
so logs/exit codes can be inspected. Checkpoint output is on the host:
OUTPUT_DIR/pi05_full_60d_multi/EXP_NAME/. Restart the container only through the
resume launch, rather than blindly re-running a new training job in the same
experiment directory. num-train-steps is the TOTAL target, not additional steps.

Set BATCH_SIZE to change the full training batch (default 4); capacity depends on
your H100 VRAM and the preserved action horizon/token length. No GPU capacity is
guaranteed. This uses one GPU, no EMA, all parameters trainable, inherited LR and
optimizer from the existing projection config; full stage early stopping is off.
It runs YOUR scripts/train.py. It does not register a new permanent TrainConfig.
Inference with the existing pi05_projection_60d_multi config matches the saved
architecture and data transformations.

Validation performed for this bundle: Python syntax/CLI and shell syntax plus
mocked runtime-config checks. Docker build and actual H100 training require the
user's modified OpenPI repo, checkpoint, data and GPU, and were not executed here.
The image recreates packages from uv.lock; edits made directly inside a host
.venv/site-packages are not carried into it. Put required package edits in a
versioned source/dependency before building.

Primary references:
- https://docs.astral.sh/uv/guides/integration/docker/
- https://docs.jax.dev/en/latest/installation.html
- https://docs.nvidia.com/datacenter/cloud-native/container-toolkit/install-guide.html
- https://github.com/Physical-Intelligence/openpi/blob/main/scripts/train.py
