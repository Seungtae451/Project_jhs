#!/usr/bin/env bash
# Launch a single GPU container; prerequisites are Docker + NVIDIA Container Toolkit.
# Required host paths are passed through environment variables, not hardcoded.
set -euo pipefail

mode="${1:-full}"
case "$mode" in
    full|smoke|preflight|resume) ;;
    *) echo 'Usage: bash scripts/run_h100.sh full|smoke|preflight|resume' >&2; exit 2 ;;
esac
: "${DATASET_DIR:?Set DATASET_DIR to the parent containing the three LeRobot datasets}"
: "${INIT_CHECKPOINT:?Set INIT_CHECKPOINT to the REAL 60-D projection checkpoint, not the dummy smoke model}"
: "${NORM_STATS_FILE:?Set NORM_STATS_FILE to the exact training norm_stats.json}"
: "${CACHE_DIR:?Set CACHE_DIR to the OpenPI cache containing big_vision/paligemma_tokenizer.model}"
: "${OUTPUT_DIR:?Set OUTPUT_DIR to the host directory for checkpoint outputs}"

dataset_path=$(realpath -e "$DATASET_DIR")
init_path=$(realpath -e "$INIT_CHECKPOINT")
stats_file=$(realpath -e "$NORM_STATS_FILE")
cache_path=$(realpath -e "$CACHE_DIR")
[[ -d "$dataset_path" && -d "$init_path" && -d "$cache_path" ]] || { echo 'Dataset, checkpoint and cache must be directories.' >&2; exit 2; }
[[ -f "$stats_file" && $(basename "$stats_file") == norm_stats.json ]] || { echo 'NORM_STATS_FILE must point to norm_stats.json.' >&2; exit 2; }
[[ -f "$cache_path/big_vision/paligemma_tokenizer.model" ]] || { echo 'Tokenizer missing from CACHE_DIR/big_vision/paligemma_tokenizer.model' >&2; exit 2; }
mkdir -p "$OUTPUT_DIR"
output_path=$(realpath -e "$OUTPUT_DIR")
stats_dir=$(dirname "$stats_file")
asset_id=$(basename "$stats_dir")

stamp=$(date +%Y%m%d_%H%M%S)
exp_name="${EXP_NAME:-full_60d_${stamp}}"
container_name="${CONTAINER_NAME:-pi05-${mode}-${stamp}}"
steps="${NUM_TRAIN_STEPS:-50000}"
batch_size="${BATCH_SIZE:-4}"
log_interval=10
save_interval=1000
extra=()
if [[ "$mode" == smoke ]]; then
    exp_name="${EXP_NAME:-h100_smoke_${stamp}}"
    steps=3
    batch_size=1
    log_interval=1
    save_interval=1
elif [[ "$mode" == preflight ]]; then
    extra+=(--preflight-only)
elif [[ "$mode" == resume ]]; then
    : "${EXP_NAME:?Resume requires the original EXP_NAME}"
    extra+=(--resume)
fi

# Check all bind sources first. --mount refuses nonexistent host sources.
# Data/norm stats/initial checkpoint are read-only. Cache and outputs are writable.
# No host .venv is mounted; use the dependencies installed in the image.
docker run -d --init \
    --name "$container_name" \
    --gpus "device=${GPU_INDEX:-0}" \
    --network none \
    --shm-size=8g \
    --mount "type=bind,src=$dataset_path,dst=/data,readonly" \
    --mount "type=bind,src=$init_path,dst=/init,readonly" \
    --mount "type=bind,src=$stats_dir,dst=/norm/$asset_id,readonly" \
    --mount "type=bind,src=$cache_path,dst=/openpi-cache" \
    --mount "type=bind,src=$output_path,dst=/checkpoints" \
    "${IMAGE_NAME:-openpi-pi05-60d:train}" \
    python scripts/run_full_train.py \
        --config-name pi05_projection_60d_multi \
        --dataset-path /data \
        --model-path /init \
        --norm-stats-path "/norm/$asset_id/norm_stats.json" \
        --exp-name "$exp_name" \
        --batch-size "$batch_size" \
        --num-workers 0 \
        --num-train-steps "$steps" \
        --log-interval "$log_interval" \
        --save-interval "$save_interval" \
        "${extra[@]}"

printf 'Container: %s\nExperiment: %s\nHost checkpoints: %s/pi05_full_60d_multi/%s\n' \
    "$container_name" "$exp_name" "$output_path" "$exp_name"
printf 'View logs: docker logs -f %s\n' "$container_name"
