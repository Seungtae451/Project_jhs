"""Run the ACTUAL local scripts/train.py with full pi0.5/60-D training.

Reuses the existing pi05_projection_60d_multi data/optimizer/LR config.
Unlike the smoke test, use gemma_2b + gemma_300m and the original image encoder.
Load a REAL 60-D projection checkpoint, not the dummy/mu smoke-test checkpoint.
The launcher changes only runtime config; it never edits the original config.py.

Normal launcher defaults: 50,000 steps, batch 4, no EMA, all parameters trainable.
--resume restores an interrupted run including optimizer state; use same exp name.
For inference the existing pi05_projection_60d_multi model/data config still matches
the saved model. The run name pi05_full_60d_multi is an output label, not a new
statically registered config in config.py.
"""
from __future__ import annotations

import argparse
import dataclasses
import importlib.util
from pathlib import Path
import sys


def build_config(args):
    import flax.nnx as nnx
    from openpi.training import config, weight_loaders

    base = config.get_config(args.config_name)
    dataset_path = args.dataset_path.expanduser().resolve()
    stats_path = args.norm_stats_path.expanduser().resolve()
    model_path = args.model_path.expanduser().resolve()
    if (model_path / 'params').is_dir():
        model_path = model_path / 'params'
    if not model_path.is_dir():
        raise FileNotFoundError(f'Initial checkpoint params directory missing: {model_path}')
    if not dataset_path.is_dir():
        raise FileNotFoundError(dataset_path)
    if not stats_path.is_file() or stats_path.name != 'norm_stats.json':
        raise FileNotFoundError(f'Expected EXACT training norm_stats.json: {stats_path}')
    if not hasattr(base.data, 'dataset_root'):
        raise ValueError('Image must contain your modified multi-dataset OpenPI config, including dataset_root.')

    # Preserve all child repo IDs, raw action keys, task prompts and input transforms.
    # Set path INSIDE the container, not the old host path saved in config.py.
    data = dataclasses.replace(
        base.data,
        dataset_root=str(dataset_path),
        assets=dataclasses.replace(
            base.data.assets,
            assets_dir=str(stats_path.parent.parent),
            asset_id=stats_path.parent.name,
        ),
    )
    # Restore REAL model sizes explicitly. Do not apply the smoke-test SigLIP patch.
    # Keep the original action horizon, max_token_len and discrete-state settings.
    model = dataclasses.replace(
        base.model, pi05=True, action_dim=60,
        paligemma_variant='gemma_2b', action_expert_variant='gemma_300m',
    )
    updates = dict(
        name='pi05_full_60d_multi', exp_name=args.exp_name,
        model=model, data=data,
        weight_loader=weight_loaders.CheckpointWeightLoader(str(model_path)),
        freeze_filter=nnx.Nothing, ema_decay=None,
        checkpoint_base_dir=str(args.checkpoint_base_dir),
        batch_size=args.batch_size, num_workers=args.num_workers,
        num_train_steps=args.num_train_steps,
        log_interval=args.log_interval, save_interval=args.save_interval,
        fsdp_devices=1, wandb_enabled=False, resume=args.resume, overwrite=False,
    )
    # Projection plateau detection should not terminate a full-training run.
    if hasattr(base, 'early_stopping'):
        updates['early_stopping'] = False
    full = dataclasses.replace(base, **updates)

    # Fail before allocating the real model if the shared 60-D stats are wrong.
    from openpi.shared import normalize
    stats = normalize.load(stats_path.parent)
    for key in ('state', 'actions'):
        if key not in stats or len(stats[key].mean) != 60:
            raise ValueError(f'Training norm stats for {key} must have 60 dimensions.')
    dc = full.data.create(full.assets_dirs, full.model)
    if dc.norm_stats is None:
        raise ValueError('Full config did not load normalization stats.')
    for rid in getattr(dc, 'repo_ids', ()):
        if not (dataset_path / rid / 'meta/info.json').is_file():
            raise FileNotFoundError(dataset_path / rid / 'meta/info.json')
    print('Configuration:', full.name, flush=True)
    print('Initial params:', model_path, flush=True)
    print('Normalization:', stats_path, flush=True)
    print('Dataset root:', dataset_path, flush=True)
    print('Checkpoint output:', full.checkpoint_dir, flush=True)
    print('Model: REAL pi0.5, action_dim=60, all parameters trainable', flush=True)
    print('Steps:', full.num_train_steps, 'batch size:', full.batch_size, flush=True)
    return full


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--config-name', default='pi05_projection_60d_multi')
    p.add_argument('--dataset-path', type=Path, required=True)
    p.add_argument('--model-path', type=Path, required=True)
    p.add_argument('--norm-stats-path', type=Path, required=True)
    p.add_argument('--exp-name', required=True)
    p.add_argument('--checkpoint-base-dir', type=Path, default=Path('/checkpoints'))
    p.add_argument('--batch-size', type=int, default=4)
    p.add_argument('--num-workers', type=int, default=0)
    p.add_argument('--num-train-steps', type=int, default=50_000)
    p.add_argument('--log-interval', type=int, default=10)
    p.add_argument('--save-interval', type=int, default=1000)
    p.add_argument('--resume', action='store_true')
    p.add_argument('--preflight-only', action='store_true')
    args = p.parse_args()
    if any(x < 1 for x in (args.batch_size, args.num_train_steps, args.log_interval, args.save_interval)):
        p.error('Batch size, step count and intervals must be positive.')
    if args.num_workers < 0:
        p.error('num-workers must be >= 0')

    import jax
    print('JAX version:', jax.__version__, 'devices:', jax.devices(), flush=True)
    if not any(device.platform == 'gpu' for device in jax.devices()):
        raise RuntimeError('No JAX GPU device found. Check --gpus, host driver and NVIDIA Container Toolkit.')
    full = build_config(args)
    if args.preflight_only:
        print('PREFLIGHT PASSED. Model weights/forward/backward have NOT been tested.', flush=True)
        return

    # Execute the SAME train.py that passed your smoke test, including your edits.
    train_path = Path(__file__).resolve().with_name('train.py')
    if not train_path.is_file():
        raise FileNotFoundError(f'Place this launcher alongside scripts/train.py: {train_path}')
    spec = importlib.util.spec_from_file_location('openpi_actual_train', train_path)
    train = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = train
    spec.loader.exec_module(train)

    # The actual train.py owns checkpoint directory initialization and resume rules.
    train.main(full)
    print('TRAINING COMPLETED:', full.checkpoint_dir, flush=True)


if __name__ == '__main__':
    main()
